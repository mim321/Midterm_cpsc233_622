﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midterm
{
    class areacalculation
    {
        double Cirleresult, Squareresult, Rectangleresult, Triangleresult;

        public double Circle(double radius)
        {
            Cirleresult = 3.14 * (radius * radius);
            return Cirleresult;
        }

        public double Square(double input)
        {
            Squareresult = input * input;
            return Squareresult;
        }

        public double Triangle(double Height, double Width)
        {
            Triangleresult = 0.5 * (Height * Width);
            return Triangleresult;
        }        public double Rectangle(double Width, double Long)
        {
            Rectangleresult = Width * Long;
            return Rectangleresult;
        }

        internal void Show()
        {
            throw new NotImplementedException();
        }
    }
}
