﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Midterm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCircle_Click(object sender, EventArgs e)
        {
            Circle tmpForm3 = new Circle();
            tmpForm3.MdiParent = this.MdiParent;
            tmpForm3.Show();
        }

        private void btnSquare_Click(object sender, EventArgs e)
        {
            Square tmpForm3 = new Square();
            tmpForm3.MdiParent = this.MdiParent;
            tmpForm3.Show();
        }

        private void btnRectangle_Click(object sender, EventArgs e)
        {
            Rectangle tmpForm3 = new Rectangle();
            tmpForm3.MdiParent = this.MdiParent;
            tmpForm3.Show();
        }

        private void btnTriangle_Click(object sender, EventArgs e)
        {
            Triangle tmpForm3 = new Triangle();
            tmpForm3.MdiParent = this.MdiParent;
            tmpForm3.Show();
        }
    }
}
