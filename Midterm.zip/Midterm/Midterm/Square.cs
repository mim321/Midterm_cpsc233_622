﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Midterm
{
    public partial class Square : Form
    {
        public Square()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            areacalculation squ = new areacalculation();
            double input = Convert.ToInt32(txtInput.Text);
            double result = 0;

            result = squ.Square(input);

            SquareResult res = new SquareResult();
            res.Show();
            res.txtResult.Text = Convert.ToString(result);
        }
    }
}
