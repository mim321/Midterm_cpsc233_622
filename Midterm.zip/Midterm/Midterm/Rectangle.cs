﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Midterm
{
    public partial class Rectangle : Form
    {
        public Rectangle()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            areacalculation rec = new areacalculation();
            double width = Convert.ToDouble(txtWidth.Text);
            double Long = Convert.ToDouble(txtLong.Text);

            double result = 0;

            result = rec.Rectangle(width, Long);

            RectangleResult res = new RectangleResult();
            res.Show();
            res.txtResult.Text = Convert.ToString(result);
        }
    }
}
