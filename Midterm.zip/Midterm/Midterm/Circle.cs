﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Midterm
{
    public partial class Circle : Form
    {
        public Circle()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            areacalculation circ = new areacalculation();
            double radius = Convert.ToInt32(txtInput.Text);
            double result = 0;

            result = circ.Circle(radius);

            CircleResult res = new CircleResult();
            res.Show();
            res.txtResult.Text = Convert.ToString(result);
        }
    }
}
